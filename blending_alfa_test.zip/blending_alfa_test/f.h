#pragma pack(push, 1)
typedef struct Pixel
{
 unsigned char b, g, r;
} Pixel;
#pragma pack(pop)

#ifndef F_H_
#define F_H_
int f(unsigned char*, unsigned char*, unsigned char*, int, int, int, int, int);
#endif // F_h_
