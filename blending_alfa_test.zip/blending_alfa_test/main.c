#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <allegro.h>
#include <allegro.h>
#define PI 3.14159265

#include "f.h"

#pragma pack(push, 1)
typedef struct BITMAPFILEHEADER
{
  short bfType;
  int bfSize;
  short bfReserved1;
  short bfReserved2;
  int bfOffBits;
} BITMAPFILEHEADER;

typedef struct BITMAPINFOHEADER
{
  int biSize;
  int biWidth;
  int biHeight;
  short biPlanes;
  short biBitCount;
  int biCompression;
  int biSizeImage;
  int biXPelsPerMeter;
  int biYPelsPerMeter;
  int biClrUsed;
  int biClrImportant;
} BITMAPINFOHEADER;

typedef struct BITMAPRUBBISH
{
  long double rub1;
  long double rub2;
  long double rub3;
  long double rub4;
  int rub5;
} BITMAPRUBBISH;
#pragma pack(pop)

//Pixel* pixout;
unsigned char* pixs_out;

int main()
{
 // PLIK 1
 FILE* ifs_1;
 ifs_1 = fopen("Input_1.bmp", "rb");

 char* temp = (char*) malloc(sizeof(char) * (sizeof(BITMAPFILEHEADER)));
 fread(temp,sizeof(BITMAPFILEHEADER),1,ifs_1);
 BITMAPFILEHEADER* bfh_1 = (BITMAPFILEHEADER*)(temp);

 //cout << hex << (int)((char)bfh->bfType) << endl;

 temp = (char*) malloc(sizeof(char) * sizeof(BITMAPINFOHEADER));
 fread(temp,sizeof(BITMAPINFOHEADER),1,ifs_1);
 BITMAPINFOHEADER* bih_1 = (BITMAPINFOHEADER*)(temp);

 //temp = (char*) malloc(sizeof(char) * sizeof(BITMAPRUBBISH));
 //fread(temp,sizeof(BITMAPRUBBISH),1,ifs_1);
 //BITMAPRUBBISH* br_1 = (BITMAPRUBBISH*)(temp);

 fseek(ifs_1,bfh_1->bfOffBits,SEEK_SET);
 int padding = 0 ;
 int width_1 = bih_1->biWidth;
 if(width_1 % 4) {
    padding = 4 - (3*width_1 % 4);
    width_1 += 4 - (width_1 % 4); // piksele w bitmapie są wyrównywane do 4 bajtów
 }

 //unsigned a=0;
 //int i = 0;
 unsigned char* pixs_1 = malloc(sizeof(char)*bih_1->biHeight*3*(bih_1->biWidth));
   fread(pixs_1,sizeof(char),bih_1->biHeight*3*(bih_1->biWidth),ifs_1);

 // PLIK 2

 FILE* ifs_2;
 ifs_2 = fopen("Input_2.bmp", "rb");

 temp = (char*) malloc(sizeof(char) * sizeof(BITMAPFILEHEADER));
 fread(temp,sizeof(BITMAPFILEHEADER),1,ifs_2);
 BITMAPFILEHEADER* bfh_2 = (BITMAPFILEHEADER*)(temp);

 temp = (char*) malloc(sizeof(char) * sizeof(BITMAPINFOHEADER));
 fread(temp,sizeof(BITMAPINFOHEADER),1,ifs_2);
 BITMAPINFOHEADER* bih_2 = (BITMAPINFOHEADER*)(temp);

 fseek(ifs_2,bfh_2->bfOffBits,SEEK_SET);

 int width_2 = bih_2->biWidth;
 if(width_2 % 4) width_2 += 4 - (width_2 % 4); // piksele w bitmapie są wyrównywane do 4 bajtów

 unsigned char* pixs_2 = malloc(sizeof(char)*bih_2->biHeight*3*(bih_2->biWidth));
   fread(pixs_2,sizeof(char),bih_2->biHeight*3*(bih_2->biWidth),ifs_2);


 // PLIK KTORY MA WSZYSTKO URATOWAC
/*
 FILE* ifs_3;
 ifs_3 = fopen("tlo.bmp", "rb");

 temp = (char*) malloc(sizeof(char) * sizeof(BITMAPFILEHEADER));
 fread(temp,sizeof(BITMAPFILEHEADER),1,ifs_3);

 BITMAPFILEHEADER* bfh_3 = (BITMAPFILEHEADER*)(temp);
*/

  unsigned x,y;
  //printf("Podaj współrzędną x : ");
  //scanf("%d",&x);
  //printf("Podaj współrzędną y : ");
  //scanf("%d",&y);

 //FILE* ofs;
// ofs = fopen("Output.bmp", "wb");
 //fwrite(bfh_1,sizeof(BITMAPFILEHEADER),1,ofs);
 //fwrite(bih_1,sizeof(BITMAPINFOHEADER),1,ofs);
// fwrite(br_1,sizeof(BITMAPRUBBISH),1,ofs);

 //pixout = malloc(sizeof(Pixel)); 
// int*a = malloc(0);
 //(void)a;
 pixs_out = malloc(sizeof(unsigned char) * 3 * bih_1->biHeight*(bih_1->biWidth) + sizeof(unsigned char) * padding * bih_1->biHeight);
 //printf("%d\n",f(pixs_out, pixs_1, pixs_2, bih_1->biHeight, bih_1->biWidth, padding, x, y));
 
 //fwrite(pixs_out,sizeof(char*),bih_1->biHeight*(bih_1->biWidth)*sizeof(unsigned char)*3  + sizeof(unsigned char) * padding * bih_1->biHeight,ofs);
 

	fclose(ifs_1);
	fclose(ifs_2);
	//fclose(ofs);	

	allegro_init();
	install_keyboard();
	set_color_depth( 24 );
	set_gfx_mode( GFX_AUTODETECT_WINDOWED,bih_1->biWidth, bih_1->biHeight, 0, 0 );
	install_mouse();
	show_mouse( screen );
	unscare_mouse();

	//BITMAP* obrazek = load_bmp( "Output.bmp", default_palette );
	BITMAP* obrazek = create_bitmap_ex(24,bih_1->biWidth, bih_1->biHeight);
	BITMAP* bufor = create_bitmap_ex(24,bih_1->biWidth, bih_1->biHeight);
	 if( !obrazek)
	{
		set_gfx_mode( GFX_TEXT, 0, 0, 0, 0 );
		allegro_message( "nie mogę załadować obrazu!" );
		allegro_exit();
		return 1;
	}
	fixed kat;
	kat = itofix(128);
	blit(obrazek, screen, 0, 0, 0, 0, obrazek->w, obrazek->h);
    	while( 1 )
	{
		if(1){
		x=obrazek->w-mouse_x;
		y=obrazek->h-mouse_y;
		//f(pixs_out, pixs_1, pixs_2, bih_1->biHeight, bih_1->biWidth, padding, x, y);
		f(*obrazek->line, pixs_1, pixs_2, bih_1->biHeight, bih_1->biWidth, padding, x, y);	
		// obrazek->line podaje w innej kolejnosci			
		//ofs = fopen("Output.bmp", "wb");
		//fwrite(bfh_1,sizeof(BITMAPFILEHEADER),1,ofs);
 		//fwrite(bih_1,sizeof(BITMAPINFOHEADER),1,ofs);
		//fwrite(pixs_out,sizeof(char*),bih_1->biHeight*(bih_1->biWidth)*sizeof(unsigned char)*3  + sizeof(unsigned char) * padding * 	bih_1->biHeight,ofs);
		//obrazek = load_bmp( "Output.bmp", default_palette );		
		//fclose(ofs);	
		rotate_sprite(bufor,obrazek,0,0,kat);
		blit(bufor, screen, 0, 0, 0, 0, obrazek->w, obrazek->h);
}
		if( keypressed() ) break;
		//readkey();
	}

	allegro_exit();

/*
float radius=0;
float sinus=0;
int j = 0;
int k = 0;
int p = 0;
 for(i=0; i<bih_1->biHeight; i++)
  {
    for(j=0,k=0; j<(bih_1->biWidth); j++, k=k+3){
        radius = sqrt((i-y)*(i-y) + (j-x)*(j-x));
        while(radius > 360){
            radius -= 360;
        }
        radius *= 2;
        sinus = sin(radius*PI/180);
        if(sinus > 0){
            pixout->b = (sinus * ((pixs_1[i*bih_1->biWidth*3 + j*3]))) + ((1-sinus) * ((pixs_2[i*bih_1->biWidth*3 + j*3])));
            pixout->g = (sinus * ((pixs_1[i*bih_1->biWidth*3 + j*3 + 1]))) + ((1-sinus) * ((pixs_2[i*bih_1->biWidth*3 + j*3 + 1])));
            pixout->r = (sinus * ((pixs_1[i*bih_1->biWidth*3 + j*3 + 2]))) + ((1-sinus) * ((pixs_2[i*bih_1->biWidth*3 + j*3 + 2])));
        }else{
            sinus = (-1)*sinus;
            pixout->b = (sinus * ((pixs_1[i*bih_1->biWidth*3 + j*3]))) + ((1-sinus) * ((pixs_2[i*bih_1->biWidth*3 + j*3])));
            pixout->g = (sinus * ((pixs_1[i*bih_1->biWidth*3 + j*3 + 1]))) + ((1-sinus) * ((pixs_2[i*bih_1->biWidth*3 + j*3 + 1])));
            pixout->r = (sinus * ((pixs_1[i*bih_1->biWidth*3 + j*3 + 2]))) + ((1-sinus) * ((pixs_2[i*bih_1->biWidth*3 + j*3 + 2])));
        }
        pixs_out[i*bih_1->biWidth*3 + j*3 + p*i] = pixout->b;
        pixs_out[i*bih_1->biWidth*3 + j*3 + 1 + p*i] = pixout->g;
        pixs_out[i*bih_1->biWidth*3 + j*3 + 2 + p*i] = pixout->r;
        if(padding != 0 && j+1 == bih_1->biWidth){
            for(p=0;p<padding;p++){
                pixs_out[i*bih_1->biWidth*3 + j*3 + 2 + p] = 0;
            }
        }
    }
   }

*/
 
//usinięcie zaalokowanej pamięci

 return 0;
}



